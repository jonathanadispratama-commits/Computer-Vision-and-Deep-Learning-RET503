### 1. Data

- Total **359** gambar, **2** kelas (`huruf_angka`, `panah`); train/val/test = 195/81/83.
- Jumlah gambar per kelas relatif seimbang (rasio terbesar:terkecil 1.0:1).
- Proporsi kelas di **val** berbeda dari train (`huruf_angka`: 35.8% di val vs 51.3% di train). Karena itu balanced accuracy dan macro-F1 lebih layak dipercaya daripada akurasi biasa.
- Data test hanya **83** gambar: satu kesalahan setara ±1.2 poin akurasi, jadi selisih kecil antar eksperimen belum tentu bermakna.

### 2. Proses training

- Mode `finetune`: 1,519,906 dari 1,519,906 parameter dilatih, 15 epoch, 27 detik. Epoch terbaik **15/15** (balanced accuracy val 0.966).
- Epoch terbaik jatuh di ujung training dan val loss masih turun (0.192 → 0.128 dalam 2 epoch terakhir): model **belum konvergen**, hasil kemungkinan masih bisa membaik dengan epoch lebih banyak.
- Akurasi val (97.5%) lebih tinggi dari akurasi train (92.8%) pada epoch terbaik. Ini lazim bila train memakai augmentasi (dan dropout aktif) sedangkan val tidak, ditambah val yang kecil. Bukan tanda overfitting.
- Epoch 1 masih lemah (akurasi val 37.0%), wajar karena lapisan klasifikasi baru belum terlatih. Perbaikan terjadi bertahap.

### 3. Evaluasi validasi dan test

- Test: akurasi **98.8%**, balanced accuracy **99.0%**, macro-F1 **98.7%**. Rentang kepercayaan 95% (Wilson) akurasi test: **93.5% – 99.8%** (82/83 benar).
- Val dan test konsisten (selisih balanced accuracy 2.5 poin).
- Recall terendah di **val**: `huruf_angka` (93.1%).
- Recall terendah di **test**: `huruf_angka` (98.0%).

### 4. Analisis kesalahan (data test)

- **1** dari 83 gambar test salah (1.2%). Arah kesalahan terbanyak: `huruf_angka` → `panah` (1×).
- Keyakinan rata-rata saat salah 0.55, saat benar 0.93.
- Semua kesalahan berkeyakinan rendah (< 0.6): model ragu, bukan salah dengan yakin. Ambang keyakinan bisa dipakai untuk menandai prediksi yang perlu dicek ulang.
- File yang salah: `huruf_angka_20261003_terang_0138.jpg`.

### 5. Latensi dan ukuran model

- CPU Colab, 1 gambar 224×224: rata-rata **10.6 ms**, median 9.6 ms, p95 18.1 ms (std 2.7). Ukuran file model 6.2 MB.
- Yang diukur hanya forward pass pada input acak. Belum termasuk baca gambar, resize, normalisasi, dan bukan perangkat target.

### 6. Rekomendasi

1. Data test kecil (83 gambar). Tambah data test, atau ulangi dengan beberapa seed / cross-validation sebelum menyimpulkan satu model lebih baik dari yang lain.
2. Naikkan `EPOCHS` (mis. 30) atau pakai LR scheduler, lalu bandingkan kurva. Training 27 detik, jadi murah dicoba.
3. Buka gambar yang salah (cuplikan di bagian Analisis kesalahan) dan cek: label salah? objek kecil, blur, atau terlalu gelap/terang? Bila kondisinya sama, tambah data pada kondisi itu.
4. Bila model akan dipasang di perangkat tertentu (mis. Raspberry Pi / HP), ukur ulang latensi di sana dengan pipeline lengkap.
5. Baru satu mode (`finetune`) yang dilatih. Kalau perlu bukti manfaat transfer learning, isi `MODES = ["scratch", "freeze", "finetune"]` di sel training lalu latih ulang.
6. Pastikan foto dari sesi pengambilan yang sama tidak terpecah ke train dan test. Kalau terpecah, angka test terlihat lebih bagus dari kemampuan sebenarnya.
