# Klasifikasi Gambar dengan MobileNetV3-Small

![python](https://img.shields.io/badge/python-3.x-blue) ![PyTorch](https://img.shields.io/badge/PyTorch-2.11.0-ee4c2c) ![test acc](https://img.shields.io/badge/test_acc-98.8%25-brightgreen) ![balanced acc](https://img.shields.io/badge/balanced_acc-99.0%25-brightgreen) ![license](https://img.shields.io/badge/license-MIT-lightgrey)

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/username-kamu/nama-repo/blob/main/transfer_learning_finetune.ipynb)

Klasifikasi gambar 2 kelas (huruf_angka, panah) memakai transfer learning MobileNetV3-Small di PyTorch. Akurasi test 98.8% (balanced accuracy 99.0%) pada 83 gambar test.

## Daftar isi
- [Hasil](#hasil)
- [Dataset](#dataset)
- [Model dan training](#model-dan-training)
- [Grafik](#grafik)
- [Analisis](#analisis)
- [Cara memakai model](#cara-memakai-model)
- [Menjalankan ulang](#menjalankan-ulang)
- [Struktur repo](#struktur-repo)

## Hasil

Model terpilih: `finetune`, dipilih dari balanced accuracy **validasi** (data test tidak dipakai untuk memilih).

| Metrik | Validasi | Test |
|---|---|---|
| Loss | 0.1281 | 0.0857 |
| Accuracy | 97.5% | 98.8% |
| Balanced accuracy | 96.5% | 99.0% |
| Macro F1 | 97.3% | 98.7% |
| Recall `huruf_angka` | 93.1% | 98.0% |
| Recall `panah` | 100.0% | 100.0% |

Latensi CPU Colab: 10.6 ms per gambar (median 9.6 ms), ukuran model 6.2 MB.

## Dataset

Jumlah gambar per split dan kelas (359 gambar):

| Split | huruf_angka | panah | Total |
|---|---|---|---|
| train | 100 | 95 | 195 |
| val | 29 | 52 | 81 |
| test | 51 | 32 | 83 |
| Total | 180 | 179 | 359 |

Transformasi data training (diambil langsung dari kode):

```text
Compose(
    Resize(size=(224, 224), interpolation=bilinear, max_size=None, antialias=True)
    RandomAffine(degrees=[-8.0, 8.0], translate=(0.05, 0.05), scale=(0.9, 1.1))
    ColorJitter(brightness=(0.7, 1.3), contrast=(0.7, 1.3), saturation=(0.8, 1.2), hue=None)
    ToTensor()
    Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
)
```

## Model dan training

| Pengaturan | Nilai |
|---|---|
| Arsitektur | MobileNetV3-Small (torchvision) |
| Mode | `finetune` (bobot awal ImageNet, semua lapisan dilatih) |
| Parameter dilatih | 1,519,906 / 1,519,906 |
| Optimizer | Adam, lr = 0.0001 |
| Epoch / batch size | 15 / 32 |
| Ukuran input | 224 × 224 |
| Loss | CrossEntropy berbobot kelas |
| Pemilihan epoch | balanced accuracy validasi tertinggi (epoch 15) |
| Seed | 42 |
| Perangkat training | cuda |
| Waktu training | 27 detik |

## Grafik

![Metrik per epoch](images/akurasi_per_epoch.png)

![Loss per epoch](images/loss_per_epoch.png)

![Confusion matrix](images/confusion_matrix.png)

## Analisis

### 1. Data

- Total **359** gambar, **2** kelas (`huruf_angka`, `panah`); train/val/test = 195/81/83.
- Jumlah gambar per kelas relatif seimbang (rasio terbesar:terkecil 1.0:1).
- Proporsi kelas di **val** berbeda dari train (`huruf_angka`: 35.8% di val vs 51.3% di train). Karena itu balanced accuracy dan macro-F1 lebih layak dipercaya daripada akurasi biasa.
- Data test hanya **83** gambar: satu kesalahan setara ±1.2 poin akurasi, jadi selisih kecil antar eksperimen belum tentu bermakna.

### 2. Proses training

- Mode `finetune`: 1,519,906 dari 1,519,906 parameter dilatih, 15 epoch, 27 detik. Epoch terbaik **15/15** (balanced accuracy val 0.966).
- Epoch terbaik jatuh di ujung training dan val loss masih turun (0.192 → 0.128 dalam 2 epoch terakhir): model **belum konvergen**, hasil kemungkinan masih bisa membaik dengan epoch lebih banyak.
- Akurasi val (97.5%) lebih tinggi dari akurasi train (92.8%) pada epoch terbaik. Ini lazim bila train memakai augmentasi (dan dropout aktif) sedangkan val tidak, ditambah val yang kecil. Bukan tanda overfitting.
- Epoch 1 masih lemah (akurasi val 37.0%), wajar karena lapisan klasifikasi baru belum terlatih. Perbaikan terjadi bertahap.

### 3. Evaluasi validasi dan test

- Test: akurasi **98.8%**, balanced accuracy **99.0%**, macro-F1 **98.7%**. Rentang kepercayaan 95% (Wilson) akurasi test: **93.5% – 99.8%** (82/83 benar).
- Val dan test konsisten (selisih balanced accuracy 2.5 poin).
- Recall terendah di **val**: `huruf_angka` (93.1%).
- Recall terendah di **test**: `huruf_angka` (98.0%).

### 4. Analisis kesalahan (data test)

- **1** dari 83 gambar test salah (1.2%). Arah kesalahan terbanyak: `huruf_angka` → `panah` (1×).
- Keyakinan rata-rata saat salah 0.55, saat benar 0.93.
- Semua kesalahan berkeyakinan rendah (< 0.6): model ragu, bukan salah dengan yakin. Ambang keyakinan bisa dipakai untuk menandai prediksi yang perlu dicek ulang.
- File yang salah: `huruf_angka_20261003_terang_0138.jpg`.

### 5. Latensi dan ukuran model

- CPU Colab, 1 gambar 224×224: rata-rata **10.6 ms**, median 9.6 ms, p95 18.1 ms (std 2.7). Ukuran file model 6.2 MB.
- Yang diukur hanya forward pass pada input acak. Belum termasuk baca gambar, resize, normalisasi, dan bukan perangkat target.

### 6. Rekomendasi

1. Data test kecil (83 gambar). Tambah data test, atau ulangi dengan beberapa seed / cross-validation sebelum menyimpulkan satu model lebih baik dari yang lain.
2. Naikkan `EPOCHS` (mis. 30) atau pakai LR scheduler, lalu bandingkan kurva. Training 27 detik, jadi murah dicoba.
3. Buka gambar yang salah (cuplikan di bagian Analisis kesalahan) dan cek: label salah? objek kecil, blur, atau terlalu gelap/terang? Bila kondisinya sama, tambah data pada kondisi itu.
4. Bila model akan dipasang di perangkat tertentu (mis. Raspberry Pi / HP), ukur ulang latensi di sana dengan pipeline lengkap.
5. Baru satu mode (`finetune`) yang dilatih. Kalau perlu bukti manfaat transfer learning, isi `MODES = ["scratch", "freeze", "finetune"]` di sel training lalu latih ulang.
6. Pastikan foto dari sesi pengambilan yang sama tidak terpecah ke train dan test. Kalau terpecah, angka test terlihat lebih bagus dari kemampuan sebenarnya.

## Cara memakai model

```python
import torch, torch.nn as nn
from PIL import Image
from torchvision import models, transforms

CLASSES = ['huruf_angka', 'panah']
IMG = 224

model = models.mobilenet_v3_small(weights=None)
model.classifier[3] = nn.Linear(model.classifier[3].in_features, len(CLASSES))
model.load_state_dict(torch.load("models/dataset_raw_1_mobilenetv3_small_finetune.pt", map_location="cpu"))
model.eval()

tf = transforms.Compose([transforms.Resize((IMG, IMG)), transforms.ToTensor(),
                         transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])
x = tf(Image.open("contoh.jpg").convert("RGB")).unsqueeze(0)
with torch.no_grad():
    probs = torch.softmax(model(x), 1)[0]
print(CLASSES[probs.argmax().item()], float(probs.max()))
```

## Menjalankan ulang

1. Buka notebook `transfer_learning_finetune.ipynb` di Google Colab (tombol di atas), lalu pilih **Runtime → Change runtime type → T4 GPU**.
2. Jalankan sel dari atas ke bawah dan unggah zip dataset ketika diminta. Kelas dan pembagian train/val/test dideteksi otomatis.
3. Untuk lingkungan lokal: `pip install -r requirements.txt`.

## Struktur repo

```text
nama-repo/
├── README.md
├── requirements.txt
├── transfer_learning_finetune.ipynb
├── images/    # grafik training dan confusion matrix
├── results/   # CSV metrik, riwayat epoch, analisis kesalahan
└── models/    # bobot model (.pt)
```

## Lisensi

MIT. Tambahkan file `LICENSE` ke repo.
