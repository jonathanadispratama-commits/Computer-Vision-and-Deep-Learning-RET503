# Klasifikasi `huruf_angka` vs `panah` dengan Transfer Learning MobileNetV3-Small

Klasifikasi gambar 2 kelas memakai MobileNetV3-Small (PyTorch / torchvision), dilatih di Google Colab.

**Kelas:** `huruf_angka` (180 gambar) dan `panah` (179 gambar). Total 359 gambar.

**Sumber data:** [image-detection (Roboflow Universe), v9](https://universe.roboflow.com/image-detection-obstn/image-detection-qixfs). Dataset deteksi objek ini dipotong/dipetakan menjadi dataset klasifikasi: tiap gambar diberi satu label (objek terbesar), lalu dicatat di `metadata.csv`.

## Isi repo

```text
.
├── README.md
├── requirements.txt
├── docs/desain_awal.md          # dokumen desain awal (per kelompok)
├── dataset_raw/
│   ├── huruf_angka/             # 180 gambar
│   ├── panah/                   # 179 gambar
│   ├── metadata.csv             # 1 baris per gambar (kelas, kondisi cahaya, split, session_id, dst.)
│   └── ringkasan_data.txt
├── notebooks/P2-MobileNetV3-Small.ipynb   # kode training + evaluasi (lengkap dengan output)
├── results/                     # CSV hasil (riwayat epoch, evaluasi, info training, kesalahan)
└── images/                      # grafik akurasi/loss per epoch, confusion matrix
```

## Dataset

| Split | huruf_angka | panah | Total |
|---|---|---|---|
| train | 100 | 95 | 195 |
| val | 29 | 52 | 81 |
| test | 51 | 32 | 83 |
| **Total** | **180** | **179** | **359** |

- Setiap kelas memiliki lebih dari 50 gambar (syarat tugas: ≥ 50 gambar/kelas).
- Pembagian train/val/test memakai kolom `split` di `metadata.csv`. Pembagian dilakukan **per `session_id`** (114 sesi): tidak ada sesi yang terpecah ke lebih dari satu split, sehingga foto yang mirip tidak bocor dari train ke test.
- Kondisi cahaya (estimasi otomatis): terang 269, redup 84, gelap 6. Kondisi gelap sangat sedikit.
- Ukuran semua gambar 416 × 416. Proporsi kelas per split tidak sama (mis. `panah` 52 di val vs 32 di test), jadi **balanced accuracy** dan macro-F1 dilaporkan di samping akurasi.

![Cuplikan dataset](images/cuplikan_dataset.png)

## Model dan training

| Pengaturan | Nilai |
|---|---|
| Arsitektur | MobileNetV3-Small (torchvision), lapisan terakhir diganti 2 kelas |
| Mode | `finetune` (bobot awal ImageNet, semua lapisan dilatih) |
| Parameter dilatih | 1,519,906 / 1,519,906 |
| Optimizer | Adam, lr = 1e-4 |
| Epoch / batch size | 15 / 32 |
| Ukuran input | 224 × 224 |
| Loss | CrossEntropy berbobot kelas |
| Pemilihan epoch | balanced accuracy validasi tertinggi (epoch 15) |
| Seed | 42 |
| Waktu training | 29 detik (GPU T4) |

Augmentasi training: `RandomAffine(8°, translate 5%, scale 0.9–1.1)` dan `ColorJitter(0.3, 0.3, 0.2)`.

## Hasil

### Tabel hasil 3 mode

| Mode | Deskripsi | Akurasi val | Bal. acc val | Akurasi test | Bal. acc test | Macro-F1 test |
|---|---|---|---|---|---|---|
| `scratch` | tanpa bobot ImageNet, semua lapisan dilatih | _isi setelah dijalankan_ | | | | |
| `freeze` | bobot ImageNet, hanya classifier dilatih | _isi setelah dijalankan_ | | | | |
| `finetune` | bobot ImageNet, semua lapisan dilatih | 97.5% | 96.6% | 98.8% | 99.0% | 98.7% |

> Baris `scratch` dan `freeze` belum terisi karena baru mode `finetune` yang dijalankan. Cara menjalankannya ada di bagian [Menjalankan ulang](#menjalankan-ulang).

Detail `finetune` (lihat `results/evaluasi_val_test.csv`):

| Metrik | Validasi | Test |
|---|---|---|
| Loss | 0.1288 | 0.0857 |
| Accuracy | 97.5% | 98.8% |
| Balanced accuracy | 96.6% | 99.0% |
| Macro F1 | 97.3% | 98.7% |
| Recall `huruf_angka` | 93.1% | 98.0% |
| Recall `panah` | 100.0% | 100.0% |

### Grafik akurasi per epoch

![Metrik per epoch](images/akurasi_per_epoch.png)

![Loss per epoch](images/loss_per_epoch.png)

### Confusion matrix

![Confusion matrix](images/confusion_matrix.png)

### Latensi model terpilih (`finetune`)

CPU Colab, 1 gambar 224 × 224, rata-rata 100 kali setelah pemanasan: **28.6 ms** (std 20.8 ms). Ukuran file model 6.2 MB.

Catatan: std besar karena CPU Colab dipakai bersama, jadi angka ini kasar. Yang diukur hanya forward pass pada input acak (belum termasuk baca gambar, resize, dan normalisasi), dan bukan pada perangkat target.

## Analisis singkat

1. **Training.** Epoch 1 masih lemah (akurasi val 37%) karena lapisan klasifikasi baru belum terlatih, lalu membaik bertahap. Epoch terbaik jatuh di epoch terakhir (15) dan val loss masih turun (0.160 → 0.129 pada 2 epoch terakhir), jadi model **belum sepenuhnya konvergen**; epoch lebih banyak kemungkinan masih membantu.
2. **Overfitting.** Akurasi train (92.3%) lebih rendah dari akurasi val (97.5%) pada epoch terbaik. Ini lazim karena train memakai augmentasi dan dropout, sedangkan val tidak, ditambah val yang kecil (81 gambar). Tidak ada tanda overfitting.
3. **Test.** Akurasi test 98.8% (82 dari 83 benar), dengan rentang kepercayaan 95% (Wilson) sekitar **93.5% – 99.8%**. Test hanya 83 gambar, jadi satu kesalahan setara ±1.2 poin akurasi dan selisih kecil antar eksperimen belum tentu bermakna. Test lebih tinggi dari val (balanced accuracy 99.0% vs 96.6%); epoch dipilih memakai val saja sehingga test tetap independen, dan selisih ini lebih mungkin berasal dari ukuran/komposisi data yang kecil.
4. **Kesalahan.** Hanya 1 gambar test salah: `huruf_angka_20261003_terang_0138.jpg` (huruf/angka diprediksi `panah`) dengan keyakinan 0.56, jadi model ragu, bukan salah dengan yakin. Kelas `panah` tidak pernah salah (recall 100%).
5. **Keterbatasan.** (a) Dataset berasal dari satu sumber dengan kondisi cahaya dominan terang (75%), sehingga performa pada gambar gelap belum teruji (hanya 6 gambar gelap). (b) Perbandingan 3 mode belum lengkap. (c) Hasil dari satu seed; sebaiknya diulang dengan beberapa seed sebelum menyimpulkan.

## Menjalankan ulang

1. Buka `notebooks/P2-MobileNetV3-Small.ipynb` di Google Colab, pilih **Runtime → Change runtime type → T4 GPU**.
2. Zip folder `dataset_raw` (berisi `huruf_angka/`, `panah/`, `metadata.csv`) dan unggah saat diminta pada sel 3. Kelas dan split terbaca otomatis dari `metadata.csv`.
3. **Untuk mengisi tabel 3 mode**, ubah baris `MODES = ["finetune"]` pada sel training menjadi `MODES = ["scratch", "freeze", "finetune"]`, lalu jalankan sel dari atas ke bawah.
4. Lingkungan lokal: `pip install -r requirements.txt`.
