# Dokumen Desain Awal

> Draf awal. Lengkapi bagian bertanda `[ISI]` dengan data kelompok sebelum dikumpulkan.

**Kelompok:** [ISI nama kelompok]
**Anggota:** [ISI nama dan NIM semua anggota]
**Tema kelompok:** [ISI, mis. Smorphi]

## 1. Tujuan

Membangun pengklasifikasi gambar 2 kelas (`huruf_angka` vs `panah`) memakai transfer learning MobileNetV3-Small, lalu membandingkan tiga mode training dan mengukur latensi model terpilih.

## 2. Alasan memilih kelas

[ISI: kaitkan dengan tema kelompok, mis. robot perlu membedakan penanda arah (panah) dari penanda huruf/angka.]

## 3. Data

- Sumber: dataset image detection di Roboflow Universe (v9), dipetakan menjadi dataset klasifikasi (satu label per gambar, objek terbesar).
- Jumlah: 180 gambar `huruf_angka` dan 179 gambar `panah` (≥ 50 gambar/kelas).
- Metadata: `dataset_raw/metadata.csv` (kelas, tanggal, kondisi cahaya, sumber file, session_id, split, rasio objek).
- Pembagian: train/val/test = 195/81/83, dibagi per `session_id` agar tidak ada kebocoran antar split.

## 4. Rancangan eksperimen

| Mode | Bobot awal | Lapisan yang dilatih | Tujuan |
|---|---|---|---|
| `scratch` | acak | semua | pembanding tanpa transfer learning |
| `freeze` | ImageNet | classifier saja | seberapa jauh fitur ImageNet cukup |
| `finetune` | ImageNet | semua (lr kecil) | biasanya terbaik pada data kecil |

Pengaturan bersama: input 224 × 224, Adam, 15 epoch, batch 32, loss berbobot kelas, epoch terbaik dipilih dari balanced accuracy validasi, seed 42.

## 5. Metrik

Akurasi, balanced accuracy, macro-F1, recall per kelas, confusion matrix, dan latensi CPU satu gambar. Model terpilih ditentukan dari hasil **validasi**, bukan test.

## 6. Risiko

- Kondisi gelap hanya 6 gambar, sehingga ketahanan terhadap cahaya redup belum teruji.
- Test kecil (83 gambar), hasil sensitif terhadap satu kesalahan.
- Latensi diukur di CPU Colab, bukan di perangkat target.

## 7. Pembagian tugas

[ISI siapa mengerjakan apa]
